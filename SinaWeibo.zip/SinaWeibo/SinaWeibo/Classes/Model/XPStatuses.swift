//
//  XPStatuses.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/13.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit

class XPStatuses: NSObject {
    
    var created_at: String?
    
    var id: Int64 = 0
    
    var text: String?
    
    var source: String?
    
    var user: XPUser?
    
    var retweeted_status:XPStatuses?
    
    var reposts_count: Int = 0
    
    var comments_count: Int = 0
    
    var attitudes_count: Int = 0
    
    var pic_urls: [XPPictureAddress]?
    
    init(dict: [String: AnyObject]) {
        super.init()
        setValuesForKeysWithDictionary(dict)
    }
    
    override func setValue(value: AnyObject?, forUndefinedKey key: String) {}
    
    override func setValue(value: AnyObject?, forKey key: String) {
        if key == "user" {
            guard let dict = value as? [String: AnyObject] else {
                return
            }
            user = XPUser(dict: dict)
        }else if key == "retweeted_status"{
            guard let dict = value as? [String: AnyObject] else {
                return
            }
            retweeted_status = XPStatuses(dict: dict)
        }else if key == "pic_urls"{
            guard let picArray = value as? [[String: AnyObject]] else {
                return
            }
            
            var tempArr = [XPPictureAddress]()
            for dict in picArray {
                let picAddress = XPPictureAddress(dict: dict)
                tempArr.append(picAddress)
            }
            pic_urls = tempArr
        } else {
            super.setValue(value, forKey: key)
        }
    }
}
