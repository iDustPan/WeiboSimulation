//
//  XPPictureAddress.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/16.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit

class XPPictureAddress: NSObject {
    
    var thumbnail_pic: String?
    
    init(dict:[String: AnyObject]) {
        super.init()
        setValuesForKeysWithDictionary(dict)
    }
    
    override func setValue(value: AnyObject?, forUndefinedKey key: String) {}

}
