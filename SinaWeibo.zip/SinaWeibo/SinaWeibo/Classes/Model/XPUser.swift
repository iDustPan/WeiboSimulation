//
//  XPUser.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/13.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit

class XPUser: NSObject {
    
    var screen_name: String?
    
    var profile_image_url: String?
    
    var mbrank: Int = 0
       //  认证类型 -1 没有认证 ，0 认证用户，2，3，5 企业认证 ， 220 达人
    var verified_type: Int = 0
    
    init(dict: [String: AnyObject]) {
        super.init()
        setValuesForKeysWithDictionary(dict)
    }
    
    override func setValue(value: AnyObject?, forUndefinedKey key: String) {
        
    }

}
