//
//  XPEmoticon.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/21.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit

class XPEmoticon: NSObject {
    /// 表情描述
    var chs: String?
    /// 图片名称
    var png: String?
    /// 图片类型： 0-图片  1-Emoji
    var type: String?
    /// Emoji表情16进制字符串
    var code: String?
    
    var iconName: String?
    
    init(dict: [String: AnyObject]) {
        super.init()
        setValuesForKeysWithDictionary(dict)
    }

    override func setValue(value: AnyObject?, forUndefinedKey key: String) {}
}
