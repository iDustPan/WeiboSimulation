//
//  XPMatchResult.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/23.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit

class XPMatchResult: NSObject {
    
    var emoticonStr: String
    var emoticonStrRange: NSRange
    
    init(emoticonStr: String, emoticonStrRange: NSRange) {
        self.emoticonStr = emoticonStr
        self.emoticonStrRange = emoticonStrRange
        super.init()
    }

}
