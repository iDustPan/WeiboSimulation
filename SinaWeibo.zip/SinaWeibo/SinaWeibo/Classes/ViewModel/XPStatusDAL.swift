//
//  XPStatusDAL.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/24.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit


// 数据库访问层：缓存用户数据及网络加载数据
class XPStatusDAL: NSObject {
    
    /// 保存首页数据
    class func cacheData(status: [[String: AnyObject]]) {
        
        // 准备sql语句
        let sql = "INSERT INTO STATUS(STATUSID, STATUS, USERID) VALUES(?,?,?)"
        let userid = XPUserAccountViewModel.defaultUserAccount.userAccount!.uid
        
        // 执行sql语句，使用事务保证数据的完整性
        XPSqliteManager.manager.dataBaseQueue?.inTransaction({ (db, rollback) in
            for value in status {
                // Int64 不能直接放到数组里面需要转成字符串
                let statusid = value["id"]!
                // 把字典转JSONData
                let statusData = try! NSJSONSerialization.dataWithJSONObject(value, options: [])
                
                // 依次执行
                let result = db.executeUpdate(sql, withArgumentsInArray: ["\(statusid)",statusData, "\(userid)"])
                
                if result == false {
                    // 如果插入失败回滚数据
                    rollback.memory = true
                    break
                }
            }
        })
        
    }
    
    /// 检查缓存数据
    class func checkCacheData(maxId: Int64, sinceId: Int64) -> [[String: AnyObject]] {
        
        var sql = "SELECT STATUSID, STATUS, USERID FROM STATUS\n"
        if maxId > 0 {
            sql += "where statusid < \(maxId)\n"
        } else {
            sql += "where statusid > \(sinceId)\n"
        }
        
        sql += "and userid = \(XPUserAccountViewModel.defaultUserAccount.userAccount!.uid)\n"
        // 排序方式
        sql += "order by statusid desc\n"
        // 返回多少记录
        sql += "limit 20\n"
        
        let result = XPSqliteManager.manager.queryResultSetWithSqlString(sql)
        
        var tempArr = [[String: AnyObject]]()
        
        for value in result {
            // 微博数据转字典
            let statusData = value["status"]! as! NSData
            let statusDict = try! NSJSONSerialization.JSONObjectWithData(statusData, options: []) as! [String: AnyObject]
            
            tempArr += [statusDict]
        }
        return tempArr
    }
    
    /// 加载数据
    class func loadData(maxId: Int64, sinceId: Int64, callBack: ((statuses: [[String: AnyObject]]) -> ())) {
        // 创建数组
        let tempArr = [[String: AnyObject]]()
        
        // 1. 查询本地是否有缓存数据（完成）
        let result = checkCacheData(maxId, sinceId: sinceId)
        
        // 2. 如果有缓存数据则直接返回缓存数据
        if result.count > 0 {
            callBack(statuses: result)
            return
        }
        
        // 3.如果没有则从网络中加载
        XPNetworkTool.sharedTools.requestStatuses(XPUserAccountViewModel.defaultUserAccount.userAccount!.access_token!, maxId:maxId, sinceId: sinceId ,resultClosure: { (response, error) -> () in
            if error != nil {
                print("网络请求异常,原因：\(error)")
                callBack(statuses: tempArr)
                return
            }
            guard let dict = response as? [String: AnyObject] else {
                print("不是一个正确的字典格式")
                callBack(statuses: tempArr)
                return
            }
            guard let statusesArray = dict["statuses"] as? [[String: AnyObject]]  else {
                print("数据解析错误")
                callBack(statuses: tempArr)
                return
            }
            
            // 4.网络数据加载完成以后，把数据缓存到本地
            cacheData(statusesArray)
            
            // 5. 把网络数据加载完毕后返回
            callBack(statuses: statusesArray)
        })
    }
    
    class func clearCacheData() {
        let date = NSDate().dateByAddingTimeInterval(-60 * 30)
        
        let dateFormater = NSDateFormatter()
        dateFormater.dateFormat = "yyyy-MM-dd HH:mm:ss"
        dateFormater.locale = NSLocale(localeIdentifier: "en_US")
        //  获取时间字符串
        let dateStr = dateFormater.stringFromDate(date)
        
        
        //  准备sql语句
        let sql = "DELETE FROM STATUS WHERE TIME < '\(dateStr)'"
        
        //  执行sql语句
        XPSqliteManager.manager.dataBaseQueue?.inDatabase({ (db) -> Void in
            let result = db.executeUpdate(sql, withArgumentsInArray: nil)
            if result {
                //  操作后影响了多少条数据
                //                db.changes()
                print("清除缓存成\(db.changes())")
            } else {
                print("清除缓存失败")
            }
        })
    }
}



























