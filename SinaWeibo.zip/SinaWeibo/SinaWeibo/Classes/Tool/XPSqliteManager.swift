//
//  XPSqliteManager.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/24.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit

let dbFileName = "sinaWeibo.db"

class XPSqliteManager: NSObject {
    
    // 单例
    static let manager: XPSqliteManager = XPSqliteManager()
    
    var dataBaseQueue: FMDatabaseQueue?
    
    private override init() {
        super.init()
        // 数据库沙盒路径
        let dbPath = (NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true).last! as NSString).stringByAppendingPathComponent(dbFileName)
        // 数据库队列
        dataBaseQueue = FMDatabaseQueue(path: dbPath)
        // 创建表
        creatTable()
    }
    
    func creatTable() -> Void {
        
        // 写在单独的文件中是为了避免太多的转义字符
        let sqlPath = NSBundle.mainBundle().pathForResource("db.sql", ofType: nil)!
        let sqlString = try! String(contentsOfFile: sqlPath)
        
        // 创建表
        dataBaseQueue?.inDatabase({ (db) in
            let result = db.executeStatements(sqlString)
            result ? print("创表成功") : print("创表失败")
        })
    }
    
    // 数据库通用查询语句
    func queryResultSetWithSqlString(sql: String) -> [[String: AnyObject]] {
        
        var tempArr = [[String: AnyObject]]()
        
        dataBaseQueue?.inDatabase({ (db) in
            let resultSet = db.executeQuery(sql, withArgumentsInArray: nil)
            // 遍历结果集
            while resultSet.next() {
                // 每一条数据库记录转化为一个字典对象
                var dict = [String: AnyObject]()
                
                for i in 0..<resultSet.columnCount() {
                    // 获取列名
                    let colName = resultSet.columnNameForIndex(i)
                    // 获取列对应的值
                    let colValue = resultSet.objectForColumnIndex(i)
                    
                    dict[colName] = colValue
                }
                
                tempArr += [dict]
            }
        })
        return tempArr
    }
}
