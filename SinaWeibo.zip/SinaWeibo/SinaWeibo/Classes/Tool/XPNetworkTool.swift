//
//  XPNetworkTool.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/12.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import AFNetworking

enum RequestType: Int {
    case GET = 0
    case POST
}

class XPNetworkTool: AFHTTPSessionManager {
    //网络请求工具类的单例
    static let sharedTools: XPNetworkTool = {
        let tools = XPNetworkTool()
        tools.responseSerializer.acceptableContentTypes?.insert("text/plain")
        return tools
    }()
    
    // MARK: - 网络请求接口
    func request(type: RequestType, URLString: String, parameter: AnyObject?, resultClosure:(successResult: AnyObject?, errorResult: NSError?)->()) {
        if type == .POST {
            POST(URLString, parameters: parameter, progress: nil, success: { (_, responseData) -> Void in
                
                resultClosure(successResult: responseData, errorResult: nil)
                
                }, failure: { (_, error) -> Void in
                    
                    resultClosure(successResult: nil, errorResult: error)
            })
            
        }else{
            
            GET(URLString, parameters: parameter, progress: nil, success: { (_, responseData) -> Void in
                
                resultClosure(successResult: responseData, errorResult: nil)
                
                }) { (responseData, error) -> Void in
                    
                    resultClosure(successResult: nil, errorResult: error)
            }
        }
    }
    
    // MARK: - 上传文件接口
    func upload(URLString: String, parameter: AnyObject?, images: [UIImage], name: String, resultClosure:(successResult: AnyObject?, errorResult: NSError?)->()) {
        
        
        POST(URLString, parameters: parameter, constructingBodyWithBlock: { (formData) -> Void in
            
            for image in images {
                let data = UIImagePNGRepresentation(image)!
                formData.appendPartWithFileData(data, name: name, fileName: "random", mimeType: "application/octet-stream")
            }
            
            }, progress: nil, success: { (_, responseData) -> Void in
                
                 resultClosure(successResult: responseData, errorResult: nil)
                
            }) { (_, error) -> Void in
                
                resultClosure(successResult: nil, errorResult: error)
        }
    }
}

// MARK: - OAuth接口
extension XPNetworkTool {
    // 获取accessToken
    func requestAccessToken(code: String, resultClosure:(successResult: AnyObject?, errorResult: NSError?)->()) {
        let parameterDict = [
            "client_id": appKey,
            "client_secret": appSecret,
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": redurectURL
        ]
        request(.POST, URLString: "https://api.weibo.com/oauth2/access_token", parameter: parameterDict) { (successResult, errorResult)->() in
            resultClosure(successResult: successResult, errorResult: errorResult)
        }
    }
    // 获取用户基本信息
    func requestUserInfo(userAcount: XPUserAccount, resultClosure:(successResult: AnyObject?, errorResult: NSError?)->()) {
        let parameterDict: [String: AnyObject] = [
            "access_token": userAcount.access_token!,
            "uid": "\(userAcount.uid)"
        ]
        request(.GET, URLString: "https://api.weibo.com/2/users/show.json", parameter: parameterDict) { (successResult, errorResult)->() in
            resultClosure(successResult: successResult, errorResult: errorResult)
        }
    }
}

// MARK: - 首页网络请求接口
extension XPNetworkTool {
    func requestStatuses(accessToken: String, maxId: Int64, sinceId: Int64 ,resultClosure:(response: AnyObject?, error: NSError?)->()) {
        let parameter: [String: AnyObject] = [
            "access_token":accessToken,
            "max_id": "\(maxId)",
            "since_id": "\(sinceId)"
        ]
        
        request(.GET, URLString: "https://api.weibo.com/2/statuses/home_timeline.json", parameter: parameter, resultClosure: resultClosure)
    }
}

// MARK: - 微博发送接口
extension XPNetworkTool {
    func statusesUpdate(accessToken: String, status: String, resultClosure:(response: AnyObject?, error: NSError?)->()) {
        let url = "https://api.weibo.com/2/statuses/update.json"
        let parameters = [
            "access_token": accessToken,
            "status": status
        ]
        request(.POST, URLString: url, parameter: parameters, resultClosure: resultClosure)
    }
    
    func statusesUpload(accessToken: String, status: String, images: [UIImage], resultClosure:(response: AnyObject?, error: NSError?)->()) {
        let url = "https://upload.api.weibo.com/2/statuses/upload.json"
        let parameters = [
            "access_token": accessToken,
            "status": status
        ]
        
        upload(url, parameter: parameters, images: images, name: "pic", resultClosure: resultClosure)
    }
    
    
}











