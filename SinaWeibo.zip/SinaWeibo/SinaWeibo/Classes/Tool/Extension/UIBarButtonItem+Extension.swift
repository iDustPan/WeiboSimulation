//
//  UIBarButtonItem+Extension.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/11.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit

extension UIBarButtonItem {
    
    // 使用便利构造函数创建对象
    convenience init(title: String, fontSize: CGFloat, target: AnyObject?, action:Selector) {
        self.init()
        
        let button = UIButton()
        button.addTarget(target, action: action, forControlEvents: .TouchUpInside)
        button.setTitle(title, forState: .Normal)
        button.setTitleColor(UIColor.darkGrayColor(), forState: .Normal)
        button.setTitleColor(UIColor.orangeColor(), forState: .Highlighted)
        
        button.titleLabel?.font = UIFont.systemFontOfSize(fontSize)
        button.sizeToFit()
        
        customView = button
    }
}
