//
//  UIButton+Extension.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/11.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit

extension UIButton {
    convenience init(title: String, fontSize: CGFloat, backgoundImg: String, target: AnyObject?, action: Selector) {
        self.init()
        addTarget(target, action: action, forControlEvents: .TouchUpInside)
        
        titleLabel?.font = UIFont.systemFontOfSize(fontSize)
        setTitle(title, forState: .Normal)
        setTitleColor(UIColor.darkGrayColor(), forState: .Normal)
        setTitleColor(UIColor.orangeColor(), forState: .Highlighted)
        setBackgroundImage(UIImage(named: backgoundImg), forState: .Normal)
    }
    
    convenience init(image: String, title: String, backgroundImg: String, hasRightLine: Bool) {
        self.init()
        titleLabel?.font = UIFont.systemFontOfSize(14)
        setTitle(title, forState: .Normal)
        setTitleColor(UIColor.darkGrayColor(), forState: .Normal)
        setTitleColor(UIColor.orangeColor(), forState: .Highlighted)
        setImage(UIImage(named: image), forState: .Normal)
        setBackgroundImage(UIImage(named: backgroundImg)?.stretchableImageWithLeftCapWidth(1, topCapHeight: 1), forState: .Normal)
        adjustsImageWhenHighlighted = false
        
        if hasRightLine {
            let lineView = UIView()
            lineView.layer.contents = UIImage(named: "timeline_card_bottom_line")?.CGImage
            lineView.sizeToFit()
            lineView.center.x = bounds.size.width
            lineView.center.y = bounds.size.height / 2
            addSubview(lineView)
        }
    }
}
