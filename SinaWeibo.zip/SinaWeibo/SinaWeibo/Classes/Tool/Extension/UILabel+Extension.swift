//
//  UILabel+Extension.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/13.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit

extension UILabel {

    
    convenience init(color: UIColor, fontSize: CGFloat) {
        self.init()
        textColor = color
        font = UIFont.systemFontOfSize(fontSize)
    }
}
