//
//  UIImage+Extension.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/20.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit

extension UIImage {
    
   class func compressImage(image: UIImage, targetWidth: CGFloat) -> UIImage {
        let targetHeight = targetWidth / image.size.width * image.size.height
        let targetSize = CGSize(width: targetWidth, height: targetHeight)
        
        UIGraphicsBeginImageContext(targetSize)
        
        image.drawInRect(CGRect(origin: CGPointZero, size: targetSize))
        var targetImage = UIGraphicsGetImageFromCurrentImageContext()
    
        targetImage = UIImage(data: UIImageJPEGRepresentation(targetImage, 1.0)!)
        
        UIGraphicsEndImageContext()
        
        return targetImage
    }
    
}

