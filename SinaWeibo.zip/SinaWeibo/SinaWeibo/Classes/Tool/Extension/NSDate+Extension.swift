//
//  NSDate+Extension.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/16.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit

let dateFormatter = NSDateFormatter()
extension NSDate {
    
    //    Mon May 16 16:19:03 +0800 2016
    //    Optional(2015-12-21 08:19:03 +0000)
    
     class func handleCreatTime(creatAt: String) -> NSDate {
        dateFormatter.locale = NSLocale(localeIdentifier: "en_US")
        dateFormatter.dateFormat = "EEE MMM dd HH:mm:ss z yyyy"
        let creatDate = dateFormatter.dateFromString(creatAt)!
        return creatDate
    }
    
    var displayTime: String? {
        return displayTimeFormatter()
    }
    
    func displayTimeFormatter() -> String {
        // 如果是今年
        if isCurrentYear(self) {
            let calendar = NSCalendar.currentCalendar()
            // 如果是今天
            if calendar.isDateInToday(self) {
                let time = abs(self.timeIntervalSinceNow)
                if time < 60 {
                    return "刚刚"
                } else if time < 60 * 60 {
                    return "\(Int(time) / 60)分钟前"
                }else {
                    return "\(Int(time) / 3600)小时前"
                }
            // 如果是昨天
            } else if calendar.isDateInYesterday(self) {
                dateFormatter.dateFormat = "昨天 HH:mm"
            // 其他
            } else {
                dateFormatter.dateFormat = "MM-dd HH:mm"
            }
        // 如果不是今年
        } else {
            dateFormatter.dateFormat = "yyyy-MM-dd HH:mm"
        }
        
        return dateFormatter.stringFromDate(self)
    }
    
    
    // MARK: - 判断是否是今年的函数
    private func isCurrentYear(date: NSDate) -> Bool {
        dateFormatter.dateFormat = "YYYY"
        let dateStr = dateFormatter.stringFromDate(date)
        let currentYear = dateFormatter.stringFromDate(NSDate())
        return dateStr == currentYear
    }

    
}
