//
//  NSAttributedString+Extension.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/23.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit

extension NSAttributedString {
    // MARK: - 根据表情图片生成对应的富文本
    class func attributedTextWithEmoticon(emoticon: XPEmoticon, font:UIFont) -> NSAttributedString {
        // 1.取得表情图片，根据表情图片生成一个自动以的带有表情模型的attachment
        let icon = UIImage(named: emoticon.iconName!)
        let attachment = XPTextAttachment()
        attachment.emoticon = emoticon
        attachment.image = icon
        
        //  取到字体的高度
        let fontHeight = font.lineHeight
        // 设置文本框中显示表情图片的大小
        attachment.bounds = CGRect(x: 0, y: -4, width: fontHeight, height: fontHeight)
        // 把文本附件转化为富文本
        let atrributedText = NSAttributedString(attachment: attachment)
    
        return atrributedText
    }
}
