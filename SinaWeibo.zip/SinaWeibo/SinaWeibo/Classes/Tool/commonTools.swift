//
//  commonTools.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/13.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit

let commonMargin: CGFloat = 10.0

let loginSuccessNotification = "notification_loginSuccess"

let screenWidth = UIScreen.mainScreen().bounds.size.width
let screenHeight = UIScreen.mainScreen().bounds.size.height

func randomColor() -> UIColor {
    let red = CGFloat(random() % 256)
    let green = CGFloat(random() % 256)
    let blue = CGFloat(random() % 256)
    return RGBcolor(red / 255, green: green / 255, blue: blue / 255)
}

func RGBcolor(red: CGFloat, green: CGFloat, blue: CGFloat) -> UIColor {
    return UIColor(red: red, green: green, blue: blue, alpha: 1)
}
