//
//  XPTextView.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/19.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit

@IBDesignable
class XPTextView: UITextView {

    private lazy var placeHolderLabel: UILabel = {
        let placeHolderLabel = UILabel()
        placeHolderLabel.textColor = UIColor.darkGrayColor()
        placeHolderLabel.numberOfLines = 0
        return placeHolderLabel
    }()
    

    
    
    
    @IBInspectable var placeHolder: String? {
        didSet {
            placeHolderLabel.text = placeHolder
        }
    }
    
    override var font: UIFont? {
        didSet {
            placeHolderLabel.font = font
        }
    }
    
    override var text: String? {
        didSet {
            placeHolderLabel.hidden = self.hasText()
        }
    }

    override init(frame: CGRect, textContainer: NSTextContainer?) {
       super.init(frame: frame, textContainer: textContainer)
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupUI()
    }
    
    func setupUI() {
        addSubview(placeHolderLabel)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(XPTextView.textViewTextChange), name: UITextViewTextDidChangeNotification, object: nil)
    }
    
    func textViewTextChange() {
        placeHolderLabel.hidden = self.hasText()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        placeHolderLabel.frame = CGRectMake(5, 8, screenWidth - 10, 0)
        placeHolderLabel.sizeToFit()
    }
    
    deinit {
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
}

extension XPTextView {
    // MARK: - 输入表情图片的方法
    func insertEmoticon(emoticon: XPEmoticon, font: UIFont) {
        if emoticon.type == "0" {
            
            let exisitingAttributedStr = NSMutableAttributedString(attributedString: self.attributedText)
            
            let newInputAttributedStr = NSAttributedString.attributedTextWithEmoticon(emoticon, font: font)
            
            // 获取光标的当前位置
            var range = self.selectedRange
            
            /// 追加富文本的方法
            // 该方法只能追加在末尾，无法在句子中间追加
//            exisitingAttributedStr.appendAttributedString(newInputAttributedStr)
            
            exisitingAttributedStr.replaceCharactersInRange(range, withAttributedString: newInputAttributedStr)
            
            // 设置富文本字体大小
            exisitingAttributedStr.addAttribute(NSFontAttributeName, value: font, range: NSMakeRange(0, exisitingAttributedStr.length))
            
            self.attributedText = exisitingAttributedStr
            
            // 更新光标位置
            range.location += 1
            range.length = 0
            self.selectedRange = range
            
        } else {
            self.insertText((emoticon.code! as NSString).emoji())
        }
        
        textViewTextChange()
        self.delegate?.textViewDidChange?(self)
    }
    
    // MARK: - 把表情图片转化为普通文本以上传的方法
    var emoticonText: String {
        var result = ""
        
        self.attributedText.enumerateAttributesInRange(NSMakeRange(0, self.attributedText.length), options: []) { (infoDict, range, stop) in
            
            if let attachment = infoDict["NSAttachment"] as? XPTextAttachment {
                
                result += (attachment.emoticon?.chs)!
            } else {
                
                result += self.attributedText.attributedSubstringFromRange(range).string
            }
        }
        
        return result
    }
}













