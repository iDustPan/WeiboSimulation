//
//  XPKeyboardButton.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/21.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit

class XPKeyboardButton: UIButton {

    var emoticon: XPEmoticon? {
        didSet {
            if emoticon!.type == "0" {
                setImage(UIImage(named: emoticon!.iconName!), forState: .Normal)
//                setImage(UIImage(contentsOfFile: emoticon!.iconName!), forState: .Normal)
                
                setTitle(nil, forState: .Normal)
            } else {
                setImage(nil, forState: .Normal)
                setTitle(emoticon!.code!.emoji(), forState: .Normal)
            }
        }
    }

}
