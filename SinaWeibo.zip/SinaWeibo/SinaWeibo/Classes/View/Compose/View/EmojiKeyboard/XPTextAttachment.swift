//
//  XPTextAttachment.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/23.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit

class XPTextAttachment: NSTextAttachment {
    
    var emoticon: XPEmoticon?

}
