//
//  XPVisitorViewController.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/11.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit

class XPVisitorViewController: UITableViewController {
    // 登录状态
    var isLogin = XPUserAccountViewModel.defaultUserAccount.isLogin
    
    let visitorView: XPVisitorView? = XPVisitorView()
    
    override func loadView() {
        isLogin ? super.loadView() : setupVisitorView()
    }
    
    func setupVisitorView() {
        view = visitorView
        visitorView!.callBack = { [weak self] in
            self?.oAuthLogin()
        }
        setupNaviUI()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    private func setupNaviUI() {
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "注册", fontSize: 16, target: self, action: #selector(XPVisitorViewController.registerAction))
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "登录", fontSize: 16, target: self, action: #selector(XPVisitorViewController.loginAction))
    }
}

// MARK: - 注册/登录 按钮点击事件
extension XPVisitorViewController {
    @objc private func registerAction() {
        oAuthLogin()
    }
    
    @objc private func loginAction() {
        oAuthLogin()
    }
    
    private func oAuthLogin() {
        let vc = XPOAuthViewController()
        let nav = UINavigationController(rootViewController: vc)
        
        presentViewController(nav, animated: true, completion: nil)
    }
}
