//
//  XPVisitorView.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/11.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit
import SnapKit


class XPVisitorView: UIView {
    
    var callBack: (()->())?

    // MARK: - 懒加载各控件
    lazy var circleImageView: UIImageView = UIImageView(image: UIImage(named: "visitordiscover_feed_image_smallicon"))
    lazy var maskImgView: UIImageView = UIImageView(image: UIImage(named: "visitordiscover_feed_mask_smallicon"))
    lazy var iconImgView: UIImageView = UIImageView(image: UIImage(named: "visitordiscover_feed_image_house"))
    lazy var remindLabel: UILabel = {
        let label = UILabel()
        label.text = "关注一些人，回这里看看有什么惊喜"
        label.numberOfLines = 2
        label.font = UIFont.systemFontOfSize(14)
        label.textColor = UIColor.darkGrayColor()
        label.textAlignment = .Center
        return label
    }()
    
    lazy var rigisterBtn: UIButton = UIButton(title: "注册", fontSize: 16, backgoundImg: "common_button_white_disable", target: self, action: #selector(XPVisitorView.rigisterAction))
    lazy var loginBtn: UIButton = UIButton(title: "登录", fontSize: 16, backgoundImg: "common_button_white_disable", target: self, action: #selector(XPVisitorView.loginAction))
    
    private func setupUI() {
        backgroundColor = UIColor(white: 237 / 255, alpha: 1)
        
        addSubview(circleImageView)
        addSubview(maskImgView)
        addSubview(iconImgView)
        addSubview(remindLabel)
        addSubview(rigisterBtn)
        addSubview(loginBtn)
    }
    // MARK: - 重写构造方法
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

// MARK: - 控件布局
extension XPVisitorView {
    override func layoutSubviews() {
        super.layoutSubviews()
        
        circleImageView.snp_makeConstraints { (make) -> Void in
            make.center.equalTo(self)
        }
        maskImgView.snp_makeConstraints(closure: { (make) -> Void in
            make.center.equalTo(self)
        })
        iconImgView.snp_makeConstraints { (make) -> Void in
            make.center.equalTo(self)
        }
        remindLabel.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(iconImgView.snp_bottom)
            make.centerX.equalTo(self)
            make.size.equalTo(CGSizeMake(224, 40))
        }
        rigisterBtn.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(remindLabel.snp_bottom).offset(10)
            make.left.equalTo(remindLabel)
            make.size.equalTo(CGSizeMake(100, 35))
        }
        loginBtn.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(remindLabel.snp_bottom).offset(10)
            make.trailing.equalTo(remindLabel)
            make.size.equalTo(CGSizeMake(100, 35))
        }
    }
}

// MARK: - 注册/登录点击事件
extension XPVisitorView {
    @objc private func rigisterAction() {
        callBack?()
    }
    
    @objc private func loginAction() {
        callBack?()
    }
}

// MARK: - 动画
extension XPVisitorView {
    func startAnimation() {
        let rotationAnimation = CABasicAnimation.init(keyPath: "transform.rotation")
        rotationAnimation.toValue = 2 * M_PI
        rotationAnimation.duration = 20
        rotationAnimation.repeatCount = MAXFLOAT
        rotationAnimation.removedOnCompletion = false
        
        circleImageView.layer.addAnimation(rotationAnimation, forKey: "rotation")
    }
}

extension XPVisitorView {
    func visitorInfo(titleInfo: String?, imageName: String?) {
        
        if let t = titleInfo, img = imageName {
            remindLabel.text = t
            iconImgView.image = UIImage(named: img)
            circleImageView.hidden = true
        }else {
            circleImageView.hidden = false
            startAnimation()
        }
    }
}



