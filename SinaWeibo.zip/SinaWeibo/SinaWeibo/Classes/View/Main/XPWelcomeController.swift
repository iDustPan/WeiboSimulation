//
//  XPWelcomeController.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/13.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit
// 欢迎界面
class XPWelcomeController: UIViewController {
    
    let userAccount = XPUserAccountViewModel.defaultUserAccount.userAccount
    
    lazy var welcomeLabel: UILabel = {
        let label = UILabel(color: UIColor.darkTextColor(), fontSize: 14)
        label.alpha = 0
        
        if let user = XPUserAccountViewModel.defaultUserAccount.userAccount {
            label.text = user.name ?? "" + ",欢迎回来~"
        }else{
            label.text = "欢迎回来~"
        }
        
        return label
    }()
    
    lazy var headerImgView: UIImageView = {
       let imgView = UIImageView(image: UIImage(named: "avatar_default_big"))
        if let user = XPUserAccountViewModel.defaultUserAccount.userAccount {
            
            imgView.sd_setImageWithURL(NSURL(string: user.avatar_large!), placeholderImage: UIImage(named: "avatar_default_big"))
        }
        imgView.layer.cornerRadius = 42.5
        imgView.layer.masksToBounds = true
        return imgView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupWelcomeView()
    }
    
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        setAnimation()
    }
    
    private func setupWelcomeView() {
        view.layer.contents = UIImage(named: "ad_background")?.CGImage
        view.addSubview(headerImgView)
        view.addSubview(welcomeLabel)
        
        headerImgView.snp_makeConstraints { (make) -> Void in
            make.centerX.equalTo(view)
            make.top.equalTo(view).offset(200)
            make.size.equalTo(CGSizeMake(85, 85))
        }
        
        welcomeLabel.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(headerImgView.snp_bottom).offset(commonMargin)
            make.centerX.equalTo(view)
            
        }
    }
    
    // MARK: -头像动画
    private func setAnimation() {
        
        headerImgView.snp_updateConstraints { (make) -> Void in
            make.top.equalTo(view).offset(100)
        }
        
        UIView.animateWithDuration(1.5, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options: [], animations: { () -> Void in
                self.view.layoutIfNeeded()
            
            }) { (_) -> Void in
                UIView.animateWithDuration(0.25, animations: { () -> Void in
                    self.welcomeLabel.alpha = 1
                    }, completion: { (_) -> Void in
                       NSNotificationCenter.defaultCenter().postNotificationName(loginSuccessNotification, object: nil)
                })
        }
    }

}
