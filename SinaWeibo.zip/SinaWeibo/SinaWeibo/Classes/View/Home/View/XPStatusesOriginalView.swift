//
//  XPStatusesOriginalCell.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/13.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit
import SDWebImage
import SnapKit

class XPStatusesOriginalView: UIView {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    var originalViewBottom: Constraint?
    // MARK: - 懒加载控件
    private lazy var pictureView: XPPictureView = XPPictureView()
    private lazy var verifiedIcon: UIImageView = UIImageView(image: UIImage(named: "avatar_vip"))
    private lazy var screenNameLabel: UILabel = UILabel(color: UIColor.darkTextColor(), fontSize: 16)
    private lazy var mbrankImageView: UIImageView = UIImageView(image: UIImage(named: "common_icon_membership"))
    private lazy var timeLabel: UILabel = UILabel(color: UIColor.orangeColor(), fontSize: 12)
    private lazy var sourceLabel: UILabel = UILabel(color: UIColor.lightGrayColor(), fontSize: 12)
    private lazy var contentLabel: UILabel = {
       let label = UILabel(color: UIColor.darkTextColor(), fontSize: 16)
        label.numberOfLines = 0;
        return label
    }()
    private lazy var headerIcon: UIImageView = {
        let headerIcon = UIImageView(image: UIImage(named: "avatar_default_big"))
        headerIcon.layer.cornerRadius = 17.5
        headerIcon.layer.masksToBounds = true
        return headerIcon
    }()

    
    // MARK: - setter赋值
    var statuses: XPStatusesCellViewModel? {
        didSet {
            if let user = statuses?.statuses?.user {
                headerIcon.sd_setImageWithURL(NSURL(string: user.profile_image_url!), placeholderImage: UIImage(named: "avatar_default_big"))
                verifiedIcon.image = statuses?.verifImage
                screenNameLabel.text = user.screen_name
            }
            /// 创建时间
            timeLabel.text = statuses?.createTime
            /// 微博来源
            sourceLabel.text = statuses?.source
            /// 原创微博正文
            contentLabel.attributedText = statuses?.originalAttributedContent
            /// 微博配图
            pictureView.picUrls = statuses?.statuses?.pic_urls
            
            self.updateSubviewsConstraints()
            mbrankImageView.image = statuses?.mBrank
        }
    }
    /// 更新约束
    private func updateSubviewsConstraints() {
        originalViewBottom?.uninstall()
        
        if statuses?.originalPicCount > 0 {
            pictureView.hidden = false
            snp_updateConstraints(closure: { (make) -> Void in
                self.originalViewBottom = make.bottom.equalTo(pictureView).offset(commonMargin).constraint
            })
            pictureView.snp_updateConstraints(closure: { (make) -> Void in
                make.size.equalTo(pictureView.pictureViewSize(statuses?.originalPicCount ?? 0))
            })
        } else {
            snp_updateConstraints(closure: { (make) -> Void in
                self.originalViewBottom = make.bottom.equalTo(contentLabel).offset(commonMargin).constraint
            })
            pictureView.hidden = true
        }
    }
    
    // MARK: - UI
    func setupUI() {
        backgroundColor = UIColor.whiteColor()
        addSubview(headerIcon)
        addSubview(verifiedIcon)
        addSubview(screenNameLabel)
        addSubview(mbrankImageView)
        addSubview(timeLabel)
        addSubview(sourceLabel)
        addSubview(contentLabel)
        addSubview(pictureView)
        
        headerIcon.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self).offset(commonMargin)
            make.leading.equalTo(self).offset(commonMargin)
            make.size.equalTo(CGSizeMake(35, 35))
        }
        
        verifiedIcon.snp_makeConstraints { (make) -> Void in
            make.centerX.equalTo(headerIcon.snp_trailing)
            make.centerY.equalTo(headerIcon.snp_bottom)
        }
        
        screenNameLabel.snp_makeConstraints { (make) -> Void in
            make.leading.equalTo(headerIcon.snp_trailing).offset(commonMargin)
            make.top.equalTo(headerIcon)
        }
        
        mbrankImageView.snp_makeConstraints { (make) -> Void in
            make.leading.equalTo(screenNameLabel.snp_trailing).offset(commonMargin)
            make.bottom.equalTo(screenNameLabel)
        }
        
        timeLabel.snp_makeConstraints { (make) -> Void in
            make.leading.equalTo(screenNameLabel)
            make.top.equalTo(screenNameLabel.snp_bottom)
        }
        
        sourceLabel.snp_makeConstraints { (make) -> Void in
            make.leading.equalTo(timeLabel.snp_trailing).offset(commonMargin)
            make.top.equalTo(timeLabel)
        }
        
        contentLabel.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(headerIcon.snp_bottom).offset(commonMargin)
            make.leading.equalTo(headerIcon)
            make.trailing.equalTo(self).offset(-commonMargin)
        }
        
        pictureView.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(contentLabel.snp_bottom).offset(commonMargin)
            make.leading.equalTo(contentLabel)
        }
        
        snp_makeConstraints { (make) -> Void in
            self.originalViewBottom = make.bottom.equalTo(contentLabel).offset(commonMargin).constraint
        }
    }
}
