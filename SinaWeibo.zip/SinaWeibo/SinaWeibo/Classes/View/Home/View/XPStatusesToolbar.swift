//
//  XPStatusesToolbar.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/13.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit

class XPStatusesToolbar: UIView {
    
    var toolBarModel: XPStatusesCellViewModel? {
        didSet {
            retweetBtn.setTitle(toolBarModel?.repostsCount, forState: .Normal)
            commetBtn.setTitle(toolBarModel?.commentCount, forState: .Normal)
            unlikeBtn.setTitle(toolBarModel?.attitudesCount, forState: .Normal)
        }
    }
    
    private lazy var retweetBtn: UIButton = self.addChildButton("赞", image: "timeline_icon_retweet")
    private lazy var commetBtn: UIButton = self.addChildButton("评论", image: "timeline_icon_comment")
    private lazy var unlikeBtn: UIButton = self.addChildButton("赞", image: "timeline_icon_unlike")
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func addChildButton(title: String, image: String) -> UIButton {
        return  UIButton(image: image, title: title, backgroundImg: "timeline_card_bottom_background", hasRightLine: true)
    }
    
    private func setupUI() {
        addSubview(retweetBtn)
        addSubview(commetBtn)
        addSubview(unlikeBtn)
        
        retweetBtn.snp_makeConstraints { (make) -> Void in
            make.leading.equalTo(self)
            make.top.equalTo(self)
            make.width.equalTo(commetBtn)
        }
        commetBtn.snp_makeConstraints { (make) -> Void in
            make.leading.equalTo(retweetBtn.snp_trailing)
            make.width.equalTo(retweetBtn)
            make.top.equalTo(self)
        }
        unlikeBtn.snp_makeConstraints { (make) -> Void in
            make.trailing.equalTo(self)
            make.top.equalTo(self)
            make.leading.equalTo(commetBtn.snp_trailing)
            make.width.equalTo(commetBtn)
        }
    }
}
