//
//  XPPictureView.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/16.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit

// item间距
let itemMargin: CGFloat = 5
// item宽度
var itemWidth: CGFloat = (screenWidth - 2 * commonMargin - 2 * itemMargin) / 3

class XPPictureView: UICollectionView {

    private let pictureViewCellId = "pictureViewCellId"

    lazy var countLabel:UILabel = UILabel()
    
    var picUrls: [XPPictureAddress]? {
        didSet {
            reloadData()
        }
    }
    
    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.itemSize = CGSizeMake(itemWidth, itemWidth)
        flowLayout.minimumLineSpacing = itemMargin
        flowLayout.minimumInteritemSpacing = itemMargin
        super.init(frame: frame, collectionViewLayout: flowLayout)
        setupUI()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        
        registerClass(XPPictureCell.self, forCellWithReuseIdentifier: pictureViewCellId)
        dataSource = self
        delegate = self
        backgroundColor = UIColor(white: 0.99, alpha: 1.0)
        scrollEnabled = false
        showsHorizontalScrollIndicator = false
        showsVerticalScrollIndicator = false
    }
    
    
    func pictureViewSize(picCount:Int) -> CGSize {
        var columns: CGFloat = CGFloat(picCount) > 3 ? 3 : CGFloat(picCount)
        if picCount == 4 { columns = 2 }
        let rows: CGFloat = CGFloat((picCount - 1) / 3 + 1)
        let picViewWidth = itemWidth * columns + (columns - 1) * itemMargin
        let picViewHeight = rows * itemWidth + (columns - 1) * itemMargin
        return CGSizeMake(picViewWidth , picViewHeight)
    }

}

// MARK: - UICollectionViewDataSource
extension XPPictureView: UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return picUrls?.count ?? 0
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier(pictureViewCellId, forIndexPath: indexPath) as! XPPictureCell
        cell.pictureAddress = picUrls![indexPath.item]
        return cell
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        let browser = SDPhotoBrowser()
        browser.delegate = self
        
        browser.currentImageIndex = indexPath.item
        browser.imageCount = picUrls!.count
        browser.sourceImagesContainerView = collectionView
        
        browser.show()
    }
}

extension XPPictureView: SDPhotoBrowserDelegate {
    
    func photoBrowser(browser: SDPhotoBrowser!, placeholderImageForIndex index: Int) -> UIImage! {
        let indexPath = NSIndexPath(forItem: index, inSection: 0)
        let cell = cellForItemAtIndexPath(indexPath) as! XPPictureCell
        return cell.myPicture.image
    }

    func photoBrowser(browser: SDPhotoBrowser!, highQualityImageURLForIndex index: Int) -> NSURL! {
//        NSString *urlStr = [[self.modelsArray[index] thumbnail_pic] stringByReplacingOccurrencesOfString:@"thumbnail" withString:@"bmiddle"];
//        return [NSURL URLWithString:urlStr];
        
        let urlStr = picUrls![index].thumbnail_pic!.stringByReplacingOccurrencesOfString("thumbnail", withString: "bmiddle")
        return NSURL(string: urlStr)
    }
    
}


/// 自定义Cell
class XPPictureCell: UICollectionViewCell {
    
    private lazy var myPicture: UIImageView = {
        let imageView = UIImageView(image: UIImage(named: "timeline_image_placeholder"))
        imageView.contentMode = .ScaleAspectFill
        imageView.clipsToBounds = true
        return imageView
    }()
    
    private lazy var GIFView: UIImageView = {
        let imageView = UIImageView(image: UIImage(named: "timeline_image_gif"))
        imageView.hidden = true
        return imageView
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI() {
        addSubview(myPicture)
        addSubview(GIFView)
        myPicture.frame = contentView.bounds
        
        GIFView.snp_makeConstraints { (make) -> Void in
            make.trailing.equalTo(myPicture)
            make.bottom.equalTo(myPicture)
        }
    }
    // 绑定模型数据
    var pictureAddress: XPPictureAddress? {
        didSet {
            guard let url = pictureAddress?.thumbnail_pic else {
                return
            }
            myPicture.sd_setImageWithURL(NSURL(string: url), placeholderImage: UIImage(named: "timeline_image_placeholder"))
            GIFView.hidden = !url.hasSuffix(".gif")
        }
    }
    
    var image: UIImage? {
        didSet {
            myPicture.image = image
        }
    }
}

