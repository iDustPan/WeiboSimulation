//
//  XPStatuesCell.swift
//  SinaWeibo
//
//  Created by 徐攀 on 16/5/13.
//  Copyright © 2016年 徐攀. All rights reserved.
//

import UIKit
import SnapKit

class XPStatuesCell: UITableViewCell {
    
    var toolBarTop: Constraint?
    
    var statusesCellViewModel: XPStatusesCellViewModel? {
        didSet {
            setMyValue()
            updateSubviewsConstraints()
        }
    }
    /// 传值
    private func setMyValue() {
        originalView.statuses = statusesCellViewModel
        retweetView.statuses = statusesCellViewModel
        toolBar.toolBarModel = statusesCellViewModel
    }
    
    /// 视有无转发微博而更新约束
    private func updateSubviewsConstraints() {
        toolBarTop?.uninstall()
        if let _ = statusesCellViewModel?.statuses?.retweeted_status?.text {
            toolBar.snp_updateConstraints(closure: { (make) -> Void in
                toolBarTop = make.top.equalTo(retweetView.snp_bottom).constraint
                retweetView.hidden = false
            })
        }else {
            retweetView.hidden = true
            toolBar.snp_updateConstraints(closure: { (make) -> Void in
            toolBarTop = make.top.equalTo(originalView.snp_bottom).constraint
            })
        }
    }
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // 原创微博视图
    private lazy var originalView: XPStatusesOriginalView = {
        let originalView = XPStatusesOriginalView()
        return originalView
    }()
    
    // 转发微博视图
    private lazy var retweetView: XPStatusesRetweetView = {
        let retweetView = XPStatusesRetweetView()
        return retweetView
    }()
    
    // 底部toolBar视图
    private lazy var toolBar: XPStatusesToolbar = {
        let toolBar = XPStatusesToolbar()
        return toolBar
    }()
    
    private func setupUI() {
        contentView.backgroundColor = UIColor(white: 0.95, alpha: 1.0)
        addChildControls()
        autoLayout()
    }
    
    private func addChildControls() {
        contentView.addSubview(originalView)
        contentView.addSubview(toolBar)
        contentView.addSubview(retweetView)
    }
    
    private func autoLayout() {
        originalView.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(contentView).offset(2)
            make.leading.equalTo(contentView)
            make.width.equalTo(contentView)
        }
        retweetView.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(originalView.snp_bottom)
            make.leading.equalTo(contentView)
            make.trailing.equalTo(contentView)
        }
        toolBar.snp_makeConstraints { (make) -> Void in
            make.leading.equalTo(contentView)
            toolBarTop = make.top.equalTo(retweetView.snp_bottom).constraint
            make.trailing.equalTo(contentView)
            make.height.equalTo(44)
        }
        contentView.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self)
            make.leading.equalTo(self)
            make.trailing.equalTo(self)
            make.bottom.equalTo(toolBar)
        }
    }
}










